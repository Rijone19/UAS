<?php 
//define('API_URL','http://satalesmana.000webhostapp.com/api/');
define('API_URL','./api/');
?>