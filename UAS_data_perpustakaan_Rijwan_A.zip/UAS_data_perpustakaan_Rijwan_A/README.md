Installation Database

1. Create Database
2. Create table member
    CREATE TABLE `member` ( 
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `nim` varchar(45) DEFAULT NULL,
        `nama` varchar(45) DEFAULT NULL,
        `telpon` varchar(45) DEFAULT NULL,
        `alamat` varchar(45) DEFAULT NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4'
